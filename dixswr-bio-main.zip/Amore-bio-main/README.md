I love programming, computer science and mathematics. I making soft for logistics business, but also i like to write compilers

